package com.day4;

import java.util.Scanner;

public class Solve5 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		int n, num1, num2, sum;
		sum=0;
		
		System.out.println("ù��° ����?");
		num1 = sc.nextInt();
		System.out.println("�ι�° ����?");
		num2 = sc.nextInt();
		
		if(num1>num2) {
			
			for(n=num2;num2<=num1;n++) {
				sum+=n;	
			}
		}
		
		if(num2<num1) {
			
			for(n=num1;num1<=num2;n++) {
				sum+=n;
			}	
		}
		
		System.out.println(sum);
		
		
	}

}
